<?php include("header.php");?>

<div class="swiper-container">
  <div class="swiper-wrapper">

  <div class="swiper-slide">
      <div class="w3-padding w3-center">
        <img src="https://growingtotspreschool.com/assets/img/logo.png" alt="" width="20%"><br>
        <p>Tiny Tots Tips</p>
      <lottie-player src="https://assets6.lottiefiles.com/private_files/lf30_uk8fs7hs.json"  background="transparent"  speed="1"  style="width: 100%; height: 35vh;"  autoplay  ></lottie-player>  
      <lottie-player src="https://assets10.lottiefiles.com/packages/lf20_lagwf6tb.json"  background="transparent"  speed="1"  style="width: 100%; height: 30vh;"  loop  autoplay></lottie-player>                         
      <small>Swipe Up For Blogs and click load more for more content</small>
      </div>
  </div>

    
    
  </div>
  <!-- <div class="swiper-pagination"></div> -->
</div>





<?php include("footer.php");?>